/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package master;

import org.apache.flink.api.common.functions.*;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.*;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.FileSystem;
import org.apache.flink.shaded.curator4.com.google.common.collect.Iterables;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.AscendingTimestampExtractor;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.EventTimeSessionWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import scala.Int;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 * Skeleton for a Flink Streaming Job.
 *
 * <p>For a tutorial how to write a Flink streaming application, check the
 * tutorials and examples on the <a href="https://flink.apache.org/docs/stable/">Flink Website</a>.
 *
 * <p>To package your application into a JAR file for execution, run
 * 'mvn clean package' on the command line.
 *
 * <p>If you change the name of the main class (with the public static void main(String[] args))
 * method, change the respective entry in the POM.xml file (simply search for 'mainClass').
 */
public class VehicleTelematics {

    static String outputFolder;

    public static void main(String[] args) throws Exception {

        if (args.length < 2) {
            throw new IllegalArgumentException("Please provide input and output paths");
        }

        String inputFile = args[0];
        outputFolder = args[1];

        File file = new File(inputFile); //"src/main/resources/sample-traffic-input.csv");
        String absolutePath = file.getAbsolutePath();


        final StreamExecutionEnvironment env =
                StreamExecutionEnvironment.getExecutionEnvironment();

        //The program must be optimized to run on a Flink cluster with 3 task manager slots available
        env.setParallelism(3);

        //Read the data from the file
        DataStream<String> vehiclesData = env.readTextFile(absolutePath).setParallelism(1);

        // Map individual telemtery events to objects
        // We key by vehicle and for each direction all the time
        // and then apply all the operation on the keyed context

        DataStream<TelmeteryDataPoint> events = vehiclesData
                .map(new MapFunction<String, TelmeteryDataPoint>() {
                    @Override
                    public TelmeteryDataPoint map(String line) throws Exception {
                        return TelmeteryDataPoint.fromString(line);
                    }
                })
                .keyBy(new KeySelector<TelmeteryDataPoint, Tuple2<Integer, Integer>>() {
                    @Override
                    public Tuple2<Integer, Integer> getKey(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return new Tuple2<>(telmeteryDataPoint.vehicleId, telmeteryDataPoint.direction);
                    }
                });

        SpeedRadar(events);
        AverageSpeedControl(events);
        AccidentReporter(events);

        env.execute("Vehicle Telematics execution");
    }

    /**
     * Detects cars that overcome the speed limit of 90 mph.
     */
    static void SpeedRadar(DataStream<TelmeteryDataPoint> events) {
        events
                .filter(new FilterFunction<TelmeteryDataPoint>() {
                    @Override
                    public boolean filter(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return telmeteryDataPoint.speed > 90;
                    }
                })
                .map(new MapFunction<TelmeteryDataPoint, Tuple6<Integer, Integer, Integer, Integer, Integer, Integer>>() {
                    @Override
                    public Tuple6<Integer, Integer, Integer, Integer, Integer, Integer> map(
                            TelmeteryDataPoint telmeteryDataPoint) throws Exception {

                        //format: Time, VID, XWay, Seg, Dir, Spd
                        return new Tuple6<>(
                                telmeteryDataPoint.timestamp,
                                telmeteryDataPoint.vehicleId,
                                telmeteryDataPoint.highway,
                                telmeteryDataPoint.segment,
                                telmeteryDataPoint.direction,
                                telmeteryDataPoint.speed);
                    }
                })
                .writeAsCsv(outputFolder + "speed-radar.csv", FileSystem.WriteMode.OVERWRITE)
                .setParallelism(1);
    }

    /**
     * Detects stopped vehicles on any segment. A vehicle is stopped when it reports at
     * least 4 consecutive events from the same position.
     */
    static void AccidentReporter(DataStream<TelmeteryDataPoint> events) {
        events
                .filter(new FilterFunction<TelmeteryDataPoint>() {
                    @Override
                    public boolean filter(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return telmeteryDataPoint.speed == 0;
                    }
                })
                .keyBy(new KeySelector<TelmeteryDataPoint, Tuple2<Integer, Integer>>() {
                    @Override
                    public Tuple2<Integer, Integer> getKey(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return new Tuple2<>(telmeteryDataPoint.vehicleId, telmeteryDataPoint.direction);
                    }
                })
                .countWindow(4, 1)
                .process(new ProcessWindowFunction<TelmeteryDataPoint,
                        Tuple7<Integer, Integer, Integer, Integer, Integer, Integer, Long>,
                        Tuple2<Integer, Integer>, GlobalWindow>() {
                    @Override
                    public void process(Tuple2<Integer, Integer> integerIntegerTuple2,
                                        Context context,
                                        Iterable<TelmeteryDataPoint> iterable,
                                        Collector<Tuple7<Integer, Integer, Integer, Integer, Integer, Integer, Long>> collector) throws Exception {

                        Iterator<TelmeteryDataPoint> iterator = iterable.iterator();
                        TelmeteryDataPoint dp = iterator.next();
                        Integer starttime = dp.timestamp;
                        Long initialPosition = dp.position;
                        Boolean accident = true;

                        Integer count = 1;

                        while (iterator.hasNext()) {
                            dp = iterator.next();
                            //check if all the 4 has the same position
                            if (initialPosition != dp.position) accident = false;
                            count += 1;
                        }

                        if (accident && count >= 4) {
                            //Time1,Time2,VID,XWay,Seg,Dir,Pos
                            //Tuple6<Integer, Integer, Integer, Integer, Integer, Integer>
                            collector.collect(new Tuple7<Integer, Integer, Integer, Integer, Integer, Integer, Long>(
                                    starttime,
                                    dp.timestamp,
                                    dp.vehicleId,
                                    dp.highway,
                                    dp.segment,
                                    dp.direction,
                                    dp.position));
                        }

                    }
                })
                .writeAsCsv(outputFolder + "accident-reporter.csv", FileSystem.WriteMode.OVERWRITE)
                .setParallelism(1);
    }

    /**
     * detects cars with an average speed higher than 60 mph between segments 52 and 56 (both included)
     * in both directions. If a car sends several reports on segments 52 or 56,
     * the ones taken for the average speed are the ones that cover a longer distance..
     */
    static void AverageSpeedControl_Old(DataStream<TelmeteryDataPoint> events) {

        //can be a custom solution or with the windows (advanced solution)
        events
                .flatMap(new RichFlatMapFunction<TelmeteryDataPoint,
                        Tuple6<Integer, Integer, Integer, Integer, Integer, Integer>>() {

                    //t1,last,count,sum
                    ValueState<Tuple4<Integer, Integer, Integer, Integer>> valuesState;
                    ArrayList<Integer> segmentsToCheck = new ArrayList<>(Arrays.asList(52, 53, 54, 55, 56));

                    @Override
                    public void flatMap(TelmeteryDataPoint telmeteryDataPoint,
                                        Collector<Tuple6<Integer, Integer, Integer, Integer, Integer, Integer>> collector) throws Exception {

                        Tuple4<Integer, Integer, Integer, Integer> metaData = valuesState.value();
                        //one of the possible segments
                        if (segmentsToCheck.contains(telmeteryDataPoint.segment)) {


                            if (metaData == null || metaData.f0 == -1) {
                                //if this is the first time because we don't have the start time yet
                                valuesState.update(new Tuple4<>(telmeteryDataPoint.timestamp,
                                        telmeteryDataPoint.segment,
                                        1,
                                        telmeteryDataPoint.speed));
                            } else {
                                //for every other entry, we will keep adding
                                valuesState.update(new Tuple4<>(metaData.f0,
                                        telmeteryDataPoint.segment,
                                        metaData.f2 + 1,
                                        metaData.f3 + telmeteryDataPoint.speed));
                            }
                        } else {

                            if (metaData != null && metaData.f0 != -1 && metaData.f2 >= 5) {
                                //if there is a start state, then we will check and emit the speed
                                // when there were 5 or more segments, calculate the average
                                Integer avg = metaData.f3 / metaData.f2;
                                if (avg > 60) {
                                    //Time1, Time2, VID, XWay, Dir, AvgSpd
                                    collector.collect(new Tuple6<Integer, Integer, Integer, Integer, Integer, Integer>(metaData.f0,
                                            telmeteryDataPoint.timestamp,
                                            telmeteryDataPoint.vehicleId,
                                            telmeteryDataPoint.highway,
                                            telmeteryDataPoint.direction,
                                            avg));
                                }
                            }

                            //we will reset all the values if there is a different segment than what we are looking for
                            valuesState.update(new Tuple4<>(-1, telmeteryDataPoint.segment, -1, -1));

                        }
                    }

                    @Override
                    public void open(Configuration parameters) throws Exception {

//                        countValueState = getRuntimeContext().getState(
//                                new ValueStateDescriptor<Integer>("countValueState", BasicTypeInfo.INT_TYPE_INFO));
//
//                        initialTimeValueState = getRuntimeContext().getState(
//                                new ValueStateDescriptor<Integer>("initialTimeValueState", BasicTypeInfo.INT_TYPE_INFO));
//
//
//                        sumValueState = getRuntimeContext().getState(
//                                new ValueStateDescriptor<Integer>("sumValueState", BasicTypeInfo.INT_TYPE_INFO));
//
//                        lastSegmentValueState = getRuntimeContext().getState(
//                                new ValueStateDescriptor<Integer>("lastSegmentValueState", BasicTypeInfo.INT_TYPE_INFO));

                        valuesState = getRuntimeContext().getState(
                                new ValueStateDescriptor<Tuple4<Integer, Integer, Integer, Integer>>("lastSegmentValueState",
                                        TypeInformation.of(new TypeHint<Tuple4<Integer, Integer, Integer, Integer>>() {
                                        })));


                    }
                })
                .writeAsCsv(outputFolder + "average-speed-control.csv", FileSystem.WriteMode.OVERWRITE)
                .setParallelism(1);
    }

    /**
     * detects cars with an average speed higher than 60 mph between segments 52 and 56 (both included)
     * in both directions. If a car sends several reports on segments 52 or 56,
     * the ones taken for the average speed are the ones that cover a longer distance..
     */
    static void AverageSpeedControl(DataStream<TelmeteryDataPoint> events) {

        events
                .filter(new FilterFunction<TelmeteryDataPoint>() {
                    @Override
                    public boolean filter(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return telmeteryDataPoint.segment >= 52 && telmeteryDataPoint.segment <= 56;
                    }
                })
                .assignTimestampsAndWatermarks(new AscendingTimestampExtractor<TelmeteryDataPoint>() {
                    @Override
                    public long extractAscendingTimestamp(TelmeteryDataPoint telmeteryDataPoint) {
                        return telmeteryDataPoint.timestamp*1000;
                    }
                })
                //For each vehicle traveling in the same direction on the same highway
                .keyBy(new KeySelector<TelmeteryDataPoint, Tuple3<Integer, Integer, Integer>>() {
                    @Override
                    public Tuple3<Integer, Integer, Integer> getKey(TelmeteryDataPoint telmeteryDataPoint) throws Exception {
                        return new Tuple3<>(telmeteryDataPoint.vehicleId,
                                telmeteryDataPoint.highway,
                                telmeteryDataPoint.direction);
                    }
                })
                //we need to have all the segement 52 to 56 and each will be reported once means 180 seconds or more
                .window(EventTimeSessionWindows.withGap(Time.seconds(180)))
                .process(new ProcessWindowFunction<TelmeteryDataPoint, Tuple6<Integer, Integer, Integer, Integer, Integer, Double>,
                        Tuple3<Integer, Integer, Integer>, TimeWindow>() {

                    @Override
                    public void process(Tuple3<Integer, Integer, Integer> integerIntegerIntegerTuple3,
                                        Context context, Iterable<TelmeteryDataPoint> iterable,
                                        Collector<Tuple6<Integer, Integer,
                                                Integer, Integer, Integer, Double>> collector) throws Exception {


                        Boolean[] allSegments = new Boolean[5]; //52 to 56 inclusive
                        Arrays.fill(allSegments, Boolean.FALSE);
                        Iterator<TelmeteryDataPoint> iterator = iterable.iterator();

                        Double avgSpeed = 0D;
                        Integer startTime = Integer.MAX_VALUE;
                        Integer finishTime = -1;

                        TelmeteryDataPoint dp = null;

                        while (iterator.hasNext()) {
                            dp = iterator.next();

                            allSegments[dp.segment - 52] = true;
                            avgSpeed += dp.speed;
                            startTime = Math.min(startTime, dp.timestamp);
                            finishTime = Math.max(finishTime, dp.timestamp);

                        }

                        //All segments are covered
                        if (!Arrays.asList(allSegments).contains(false)) {

                            //calculate the average speed
                            avgSpeed /= Iterables.size(iterable);

                            //Time1, Time2, VID, XWay, Dir, AvgSpd
                            collector.collect(new Tuple6<>(startTime, finishTime, dp.vehicleId,
                                    dp.highway, dp.direction, avgSpeed));

                        }
                    }
                })
                .writeAsCsv(outputFolder + "average-speed-control.csv", FileSystem.WriteMode.OVERWRITE)
                .setParallelism(1);

    }
}
